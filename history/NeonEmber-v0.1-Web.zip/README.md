# 霓虹余烬 · Roguelite Prototype v0.1

这是 NeonEmber 最初的浏览器原型版本，使用单个 HTML 文件运行。

## 运行

双击 `rogue-neon.html`，或在浏览器中打开它。无需安装、无需联网。

## 操作

- WASD / 方向键：移动
- 武器自动瞄准最近的敌人
- 升级时从三张卡牌中选择
- Esc：暂停 / 继续

v0.1 是网页原型；v0.2 起改为 Windows x64 免安装客户端。
