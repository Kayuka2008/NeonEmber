# 本游戏的本地 MCP 开发接口

标准 stdio MCP，使用 Node.js 内置模块，无 npm 依赖，不开放网络端口。服务只允许构建本游戏、运行固定测试和渲染白名单场景，不提供任意 shell、任意路径读写或其他软件的桌面控制。

## 客户端配置

在支持 MCP 的宿主中添加 stdio 服务，command 为本机 `node`，args 为 `dev/mcp-server.cjs` 的绝对路径。例如（解压位置变化时请更新路径）：

```json
{
  "mcpServers": {
    "neon-ember-dev": {
      "command": "node",
      "args": ["C:/Users/Kayeung/Documents/Codex/2026-10-11/new-chat-3/outputs/NeonEmber/dev/mcp-server.cjs"]
    }
  }
}
```

本交付没有修改你其他软件的全局 MCP 配置。当前已通过随附的 `call.cjs` MCP 客户端完成 initialize 握手与 tools/call；如在其他宿主接入，可复用上面的服务。游戏玩家不需要启动 MCP。

## 工具

| 工具 | 参数 | 结果 |
|---|---|---|
| `game_build` | `{}` | 编译最终客户端，返回路径和大小 |
| `game_test` | `{}` | 26 项回归与长局诊断，返回报告 |
| `game_scene` | `{"scene":"level"}` | 在独立进程渲染真实客户端画面，返回 PNG 路径和场景状态 |
| `game_status` | `{}` | 当前构建与报告文件列表 |

支持场景：`menu`、`play`、`level`、`shop`、`boss`、`pause`、`help`、`build`、`over`、`stress`。

场景是确定性开发夹具，用于直接覆盖 UI 状态；不劫持正在游玩的客户端，也不会修改正式纪录。`stress` 额外采样 210 帧，返回平均/P95 渲染提交与呈现耗时，不包括逻辑模拟。其他场景只作截图，没有性能样本，因此对应字段为 0。结果在 `dev/reports/`。

## 直接使用随附 MCP 客户端

在游戏目录执行：

```powershell
node dev/call.cjs game_build
node dev/call.cjs game_test
node dev/call.cjs game_scene '{"scene":"boss"}'
node dev/call.cjs game_status
```

构建前关闭正在运行的游戏，避免 Windows 锁定 exe。测试失败会返回 MCP `isError`，调用客户端也返回非零退出码。

只运行核心模拟也可直接编译 `src/Game.cs` 与 `dev/GameTests.cs`。测试可接受报告路径参数；第二参数 `quick` 跳过长局机器人诊断。
