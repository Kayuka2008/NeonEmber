# Game simulation verification
Independent C# core tests; no renderer, input device or human gameplay assertions. Bot timing is diagnostic, not evidence of human balance. Wall time measures simulation only, not rendered FPS.
PASS | Start/reset and three loadouts
PASS | Upgrade resumes simulation
PASS | Overflow XP queues multiple levels and invalid choice is harmless
PASS | Death has priority over level up
PASS | Lethal contact and XP pickup in same frame prioritizes death
PASS | Dash cooldown prevents retrigger and expires
CONTACT | 30fps=170 60fps=170 144fps=170
PASS | Contact damage is substantial and approximately FPS independent
PASS | AOE warning delays damage and fixed target can be dodged
PASS | Shop balance, insufficient funds, and frozen combat clock
PASS | Boss schedule and no stacked bosses
PASS | Boss overlap defers shop until boss dies
PASS | Orb capacity merges value rather than dropping reward
PASS | Upgrade card pool remains usable after extensive progression
BOSS | weapon=0 seed=41 spawned=180.00s lifetime=9.23s
BOT | weapon=0 seed=41 immortal=False time=299.3s level=22 kills=854 hp=0.0 upgrades=21 interval_mean=13.71s median=12.99s max=23.29s target15to25=7/21 peaks(enemy/shot/orb/effect)=44/35/42/23 sim_steps=17960 wall=0.03s
PASS | Normal-health diagnostic bot weapon 0
BOSS | weapon=1 seed=42 spawned=180.00s lifetime=16.38s
BOT | weapon=1 seed=42 immortal=False time=328.3s level=24 kills=973 hp=0.0 upgrades=23 interval_mean=14.21s median=14.35s max=23.84s target15to25=10/23 peaks(enemy/shot/orb/effect)=50/29/39/36 sim_steps=19702 wall=0.03s
PASS | Normal-health diagnostic bot weapon 1
BOT | weapon=2 seed=43 immortal=False time=82.2s level=6 kills=105 hp=0.0 upgrades=5 interval_mean=13.26s median=11.62s max=23.32s target15to25=1/5 peaks(enemy/shot/orb/effect)=37/9/11/9 sim_steps=4930 wall=0.01s
PASS | Normal-health diagnostic bot weapon 2
BOSS | weapon=1 seed=198 spawned=180.00s lifetime=17.08s
BOSS | weapon=1 seed=198 spawned=360.01s lifetime=19.06s
BOSS | weapon=1 seed=198 spawned=540.01s lifetime=17.90s
BOSS | weapon=1 seed=198 spawned=720.00s lifetime=6.02s
BOT | weapon=1 seed=198 immortal=True time=900.0s level=54 kills=5340 hp=99868.3 upgrades=53 interval_mean=16.85s median=17.78s max=24.53s target15to25=36/53 peaks(enemy/shot/orb/effect)=96/66/47/49 sim_steps=54011 wall=0.12s
PASS | 900-second long run finite values and entity limits
BOSS | weapon=0 seed=210 spawned=180.00s lifetime=16.45s
BOSS | weapon=0 seed=210 spawned=360.01s lifetime=9.73s
BOSS | weapon=0 seed=210 spawned=540.01s lifetime=7.70s
BOSS | weapon=0 seed=210 spawned=720.00s lifetime=17.23s
BOT | weapon=0 seed=210 immortal=True time=900.0s level=51 kills=5338 hp=99983.8 upgrades=50 interval_mean=17.91s median=18.66s max=27.01s target15to25=31/50 peaks(enemy/shot/orb/effect)=96/83/51/56 sim_steps=54011 wall=0.12s
PASS | Final multiseed 900-second run 0
BOSS | weapon=1 seed=211 spawned=180.00s lifetime=34.86s
BOSS | weapon=1 seed=211 spawned=360.01s lifetime=16.81s
BOSS | weapon=1 seed=211 spawned=540.01s lifetime=11.61s
BOSS | weapon=1 seed=211 spawned=720.00s lifetime=7.75s
BOT | weapon=1 seed=211 immortal=True time=900.0s level=56 kills=5329 hp=99948.3 upgrades=55 interval_mean=16.20s median=16.61s max=24.39s target15to25=36/55 peaks(enemy/shot/orb/effect)=99/50/52/51 sim_steps=54011 wall=0.12s
PASS | Final multiseed 900-second run 1
BOSS | weapon=2 seed=212 spawned=180.00s lifetime=10.21s
BOSS | weapon=2 seed=212 spawned=360.01s lifetime=15.41s
BOSS | weapon=2 seed=212 spawned=540.01s lifetime=17.75s
BOSS | weapon=2 seed=212 spawned=720.00s lifetime=14.98s
BOT | weapon=2 seed=212 immortal=True time=900.0s level=54 kills=5309 hp=99847.5 upgrades=53 interval_mean=16.95s median=17.30s max=35.26s target15to25=32/53 peaks(enemy/shot/orb/effect)=108/53/75/48 sim_steps=54011 wall=0.13s
PASS | Final multiseed 900-second run 2
BOSS | weapon=0 seed=213 spawned=180.00s lifetime=9.43s
BOSS | weapon=0 seed=213 spawned=360.01s lifetime=9.95s
BOSS | weapon=0 seed=213 spawned=540.01s lifetime=6.33s
BOSS | weapon=0 seed=213 spawned=720.00s lifetime=8.08s
BOT | weapon=0 seed=213 immortal=True time=900.0s level=51 kills=5328 hp=99923.8 upgrades=50 interval_mean=17.98s median=18.60s max=26.48s target15to25=33/50 peaks(enemy/shot/orb/effect)=102/55/46/52 sim_steps=54011 wall=0.12s
PASS | Final multiseed 900-second run 3
BOSS | weapon=1 seed=214 spawned=180.00s lifetime=44.17s
BOSS | weapon=1 seed=214 spawned=360.01s lifetime=23.56s
BOSS | weapon=1 seed=214 spawned=540.01s lifetime=11.33s
BOSS | weapon=1 seed=214 spawned=720.00s lifetime=15.53s
BOT | weapon=1 seed=214 immortal=True time=900.0s level=52 kills=5313 hp=99526.5 upgrades=51 interval_mean=17.41s median=18.06s max=24.73s target15to25=33/51 peaks(enemy/shot/orb/effect)=109/63/34/50 sim_steps=54011 wall=0.12s
PASS | Final multiseed 900-second run 4
BOSS | weapon=2 seed=215 spawned=180.00s lifetime=24.16s
BOSS | weapon=2 seed=215 spawned=360.01s lifetime=27.74s
BOSS | weapon=2 seed=215 spawned=540.01s lifetime=4.70s
BOSS | weapon=2 seed=215 spawned=720.00s lifetime=25.54s
BOT | weapon=2 seed=215 immortal=True time=900.0s level=53 kills=5319 hp=99567.8 upgrades=52 interval_mean=17.09s median=17.95s max=25.63s target15to25=32/52 peaks(enemy/shot/orb/effect)=118/66/38/49 sim_steps=54011 wall=0.13s
PASS | Final multiseed 900-second run 5
BOSS | weapon=0 seed=216 spawned=180.00s lifetime=4.38s
BOSS | weapon=0 seed=216 spawned=360.01s lifetime=11.83s
BOSS | weapon=0 seed=216 spawned=540.01s lifetime=8.51s
BOSS | weapon=0 seed=216 spawned=720.00s lifetime=10.21s
BOT | weapon=0 seed=216 immortal=True time=900.0s level=58 kills=5336 hp=99904.3 upgrades=57 interval_mean=15.77s median=15.75s max=25.58s target15to25=32/57 peaks(enemy/shot/orb/effect)=105/51/46/52 sim_steps=54011 wall=0.12s
PASS | Final multiseed 900-second run 6
BOSS | weapon=1 seed=217 spawned=180.00s lifetime=22.74s
BOSS | weapon=1 seed=217 spawned=360.01s lifetime=9.65s
BOSS | weapon=1 seed=217 spawned=540.01s lifetime=8.70s
BOSS | weapon=1 seed=217 spawned=720.00s lifetime=21.44s
BOT | weapon=1 seed=217 immortal=True time=900.0s level=57 kills=5320 hp=99670.5 upgrades=56 interval_mean=15.91s median=16.35s max=23.71s target15to25=34/56 peaks(enemy/shot/orb/effect)=110/72/41/55 sim_steps=54011 wall=0.12s
PASS | Final multiseed 900-second run 7
BOSS | weapon=2 seed=218 spawned=180.00s lifetime=13.40s
BOSS | weapon=2 seed=218 spawned=360.01s lifetime=12.86s
BOSS | weapon=2 seed=218 spawned=540.01s lifetime=16.46s
BOSS | weapon=2 seed=218 spawned=720.00s lifetime=17.08s
BOT | weapon=2 seed=218 immortal=True time=900.0s level=54 kills=5315 hp=99930.4 upgrades=53 interval_mean=16.86s median=16.88s max=34.37s target15to25=31/53 peaks(enemy/shot/orb/effect)=99/57/80/48 sim_steps=54011 wall=0.12s
PASS | Final multiseed 900-second run 8
RESULT | passed=26 failed=0
