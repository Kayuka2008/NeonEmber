# v0.3 验证报告索引

- 核心回归与长局模拟：reports/simulation.md（26 项通过）
- 协同 AI、世界体系与剧情：reports/tactics.md（23 项通过）
- 测试方法与边界说明：tactics-review.md
- MCP 握手、白名单与工具调用：reports/mcp-protocol.md
- 原生升级转商店点击回归：reports/transition.json / transition.png。客户端在首帧断言金币保持 200、只应用 1 次升级、3 件商品仍在；失败会使场景调用返回非零。
- 实际游戏画面：reports/ 下的 PNG，含战术预警、三系升级、档案及构筑。

模拟性能不是渲染帧率，机器人存活与成长不是对真人平衡的证明。历史 v0.2 已保留在独立压缩包；本目录交付为 v0.3。
