# Game simulation verification
Independent C# core tests; no renderer, input device or human gameplay assertions. Bot timing is diagnostic, not evidence of human balance. Wall time measures simulation only, not rendered FPS.
PASS | Start/reset and three loadouts
PASS | Upgrade resumes simulation
PASS | Overflow XP queues multiple levels and invalid choice is harmless
PASS | Death has priority over level up
PASS | Lethal contact and XP pickup in same frame prioritizes death
PASS | Dash cooldown prevents retrigger and expires
CONTACT | 30fps=170 60fps=170 144fps=170
PASS | Contact damage is substantial and approximately FPS independent
PASS | AOE warning delays damage and fixed target can be dodged
PASS | Shop balance, insufficient funds, and frozen combat clock
PASS | Boss schedule and no stacked bosses
PASS | Boss overlap defers shop until boss dies
PASS | Orb capacity merges value rather than dropping reward
PASS | Upgrade card pool remains usable after extensive progression
BOT | weapon=0 seed=41 immortal=False time=188.1s level=15 kills=432 hp=0.0 upgrades=14 interval_mean=12.33s median=13.06s max=21.28s target15to25=6/14 peaks(enemy/shot/orb/effect)=26/26/40/27 sim_steps=11284 wall=0.03s
TACTICAL | weapon=0 seed=41 hazards_peak=4 special_attacks_peak=3
PASS | Normal-health diagnostic bot weapon 0
BOT | weapon=1 seed=42 immortal=False time=191.4s level=16 kills=442 hp=0.0 upgrades=15 interval_mean=11.88s median=12.08s max=23.01s target15to25=3/15 peaks(enemy/shot/orb/effect)=28/24/47/33 sim_steps=11483 wall=0.02s
TACTICAL | weapon=1 seed=42 hazards_peak=4 special_attacks_peak=3
PASS | Normal-health diagnostic bot weapon 1
BOT | weapon=2 seed=43 immortal=False time=112.4s level=10 kills=197 hp=0.0 upgrades=9 interval_mean=11.66s median=10.04s max=20.73s target15to25=4/9 peaks(enemy/shot/orb/effect)=56/9/14/20 sim_steps=6745 wall=0.02s
TACTICAL | weapon=2 seed=43 hazards_peak=3 special_attacks_peak=3
PASS | Normal-health diagnostic bot weapon 2
BOSS | weapon=1 seed=198 spawned=180.00s lifetime=14.63s
BOSS | weapon=1 seed=198 spawned=360.01s lifetime=19.58s
BOSS | weapon=1 seed=198 spawned=540.01s lifetime=17.73s
BOSS | weapon=1 seed=198 spawned=720.00s lifetime=26.99s
BOT | weapon=1 seed=198 immortal=True time=900.0s level=51 kills=5307 hp=100000.0 upgrades=50 interval_mean=17.97s median=19.66s max=30.71s target15to25=27/50 peaks(enemy/shot/orb/effect)=111/40/135/68 sim_steps=54011 wall=0.24s
TACTICAL | weapon=1 seed=198 hazards_peak=5 special_attacks_peak=3
PASS | 900-second long run finite values and entity limits
BOSS | weapon=0 seed=210 spawned=180.00s lifetime=8.33s
BOSS | weapon=0 seed=210 spawned=360.01s lifetime=7.66s
BOSS | weapon=0 seed=210 spawned=540.01s lifetime=18.80s
BOSS | weapon=0 seed=210 spawned=720.00s lifetime=7.30s
BOT | weapon=0 seed=210 immortal=True time=900.0s level=51 kills=5315 hp=100000.0 upgrades=50 interval_mean=17.93s median=20.17s max=27.16s target15to25=29/50 peaks(enemy/shot/orb/effect)=107/34/63/67 sim_steps=54011 wall=0.23s
TACTICAL | weapon=0 seed=210 hazards_peak=5 special_attacks_peak=3
PASS | Final multiseed 900-second run 0
BOSS | weapon=1 seed=211 spawned=180.00s lifetime=21.86s
BOSS | weapon=1 seed=211 spawned=360.01s lifetime=12.26s
BOSS | weapon=1 seed=211 spawned=540.01s lifetime=9.66s
BOSS | weapon=1 seed=211 spawned=720.00s lifetime=20.68s
BOT | weapon=1 seed=211 immortal=True time=900.0s level=51 kills=5314 hp=100000.0 upgrades=50 interval_mean=17.94s median=19.18s max=27.04s target15to25=27/50 peaks(enemy/shot/orb/effect)=128/40/46/66 sim_steps=54011 wall=0.25s
TACTICAL | weapon=1 seed=211 hazards_peak=5 special_attacks_peak=3
PASS | Final multiseed 900-second run 1
BOSS | weapon=2 seed=212 spawned=180.00s lifetime=6.80s
BOSS | weapon=2 seed=212 spawned=360.01s lifetime=14.68s
BOSS | weapon=2 seed=212 spawned=540.01s lifetime=16.78s
BOSS | weapon=2 seed=212 spawned=720.00s lifetime=30.78s
BOT | weapon=2 seed=212 immortal=True time=900.0s level=51 kills=5318 hp=100000.0 upgrades=50 interval_mean=17.94s median=19.75s max=30.39s target15to25=29/50 peaks(enemy/shot/orb/effect)=114/35/74/66 sim_steps=54011 wall=0.24s
TACTICAL | weapon=2 seed=212 hazards_peak=5 special_attacks_peak=3
PASS | Final multiseed 900-second run 2
BOSS | weapon=0 seed=213 spawned=180.00s lifetime=17.16s
BOSS | weapon=0 seed=213 spawned=360.01s lifetime=16.06s
BOSS | weapon=0 seed=213 spawned=540.01s lifetime=12.51s
BOSS | weapon=0 seed=213 spawned=720.00s lifetime=25.46s
BOT | weapon=0 seed=213 immortal=True time=900.0s level=51 kills=5313 hp=100000.0 upgrades=50 interval_mean=17.99s median=20.01s max=26.66s target15to25=29/50 peaks(enemy/shot/orb/effect)=115/38/42/68 sim_steps=54011 wall=0.23s
TACTICAL | weapon=0 seed=213 hazards_peak=5 special_attacks_peak=3
PASS | Final multiseed 900-second run 3
BOSS | weapon=1 seed=214 spawned=180.00s lifetime=10.81s
BOSS | weapon=1 seed=214 spawned=360.01s lifetime=25.48s
BOSS | weapon=1 seed=214 spawned=540.01s lifetime=10.38s
BOSS | weapon=1 seed=214 spawned=720.00s lifetime=35.59s
BOT | weapon=1 seed=214 immortal=True time=900.0s level=51 kills=5308 hp=100000.0 upgrades=50 interval_mean=17.92s median=19.96s max=27.34s target15to25=31/50 peaks(enemy/shot/orb/effect)=120/43/40/66 sim_steps=54011 wall=0.23s
TACTICAL | weapon=1 seed=214 hazards_peak=5 special_attacks_peak=3
PASS | Final multiseed 900-second run 4
BOSS | weapon=2 seed=215 spawned=180.00s lifetime=24.51s
BOSS | weapon=2 seed=215 spawned=360.01s lifetime=25.01s
BOSS | weapon=2 seed=215 spawned=540.01s lifetime=29.16s
BOSS | weapon=2 seed=215 spawned=720.00s lifetime=38.62s
BOT | weapon=2 seed=215 immortal=True time=900.0s level=51 kills=5298 hp=100000.0 upgrades=50 interval_mean=17.96s median=19.91s max=27.33s target15to25=28/50 peaks(enemy/shot/orb/effect)=129/36/74/70 sim_steps=54011 wall=0.27s
TACTICAL | weapon=2 seed=215 hazards_peak=5 special_attacks_peak=3
PASS | Final multiseed 900-second run 5
BOSS | weapon=0 seed=216 spawned=180.00s lifetime=4.53s
BOSS | weapon=0 seed=216 spawned=360.01s lifetime=10.78s
BOSS | weapon=0 seed=216 spawned=540.01s lifetime=11.43s
BOSS | weapon=0 seed=216 spawned=720.00s lifetime=20.84s
BOT | weapon=0 seed=216 immortal=True time=900.0s level=50 kills=5299 hp=100000.0 upgrades=49 interval_mean=17.82s median=18.90s max=28.36s target15to25=30/49 peaks(enemy/shot/orb/effect)=129/36/66/78 sim_steps=54011 wall=0.25s
TACTICAL | weapon=0 seed=216 hazards_peak=5 special_attacks_peak=3
PASS | Final multiseed 900-second run 6
BOSS | weapon=1 seed=217 spawned=180.00s lifetime=16.05s
BOSS | weapon=1 seed=217 spawned=360.01s lifetime=10.93s
BOSS | weapon=1 seed=217 spawned=540.01s lifetime=18.36s
BOSS | weapon=1 seed=217 spawned=720.00s lifetime=25.06s
BOT | weapon=1 seed=217 immortal=True time=900.0s level=51 kills=5295 hp=99995.2 upgrades=50 interval_mean=17.99s median=18.93s max=28.51s target15to25=30/50 peaks(enemy/shot/orb/effect)=120/37/41/65 sim_steps=54011 wall=0.25s
TACTICAL | weapon=1 seed=217 hazards_peak=5 special_attacks_peak=3
PASS | Final multiseed 900-second run 7
BOSS | weapon=2 seed=218 spawned=180.00s lifetime=14.76s
BOSS | weapon=2 seed=218 spawned=360.01s lifetime=18.70s
BOSS | weapon=2 seed=218 spawned=540.01s lifetime=9.25s
BOSS | weapon=2 seed=218 spawned=720.00s lifetime=27.63s
BOT | weapon=2 seed=218 immortal=True time=900.0s level=51 kills=5279 hp=100000.0 upgrades=50 interval_mean=17.96s median=19.25s max=30.84s target15to25=32/50 peaks(enemy/shot/orb/effect)=137/37/33/76 sim_steps=54011 wall=0.26s
TACTICAL | weapon=2 seed=218 hazards_peak=5 special_attacks_peak=3
PASS | Final multiseed 900-second run 8
RESULT | passed=26 failed=0
