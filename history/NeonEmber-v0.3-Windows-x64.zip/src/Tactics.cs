using System;
using System.Collections.Generic;

namespace NeonEmber
{
    public partial class Enemy
    {
        // GuardId is reciprocal: guard -> protected unit, protected unit -> guard.
        public int RelayId, GuardId;
        public float Stun, Recovery, OrderX, OrderY;
        public bool Shielded, RelayBroken;
        public string Order = "追踪";
    }

    public class Hazard
    {
        public int OwnerId;
        public float X, Y, R, Warning, Life, Damage;
    }

    public partial class Game
    {
        public const int HazardLimit = 12, SpecialAttackLimit = 3;
        public float PlayerVX, PlayerVY;
        public int FocusTargetId;
        public string TacticName = "游猎 · 观察前摇后转向";
        public List<Hazard> Hazards = new List<Hazard>();
        private readonly Dictionary<int, Enemy> tacticalIndex = new Dictionary<int, Enemy>();
        private float tacticClock, nextSquad, nextSpecial;

        private void ResetTactics()
        {
            PlayerVX = PlayerVY = 0; FocusTargetId = 0; tacticClock = nextSpecial = 0;
            nextSquad = 45; Hazards.Clear(); tacticalIndex.Clear();
            TacticName = "游猎 · 观察前摇后转向";
        }

        private void ObserveMovement(float dt, float previousX, float previousY)
        {
            // Only displacement already observed is available to enemy planning. Do not use input.
            float vx = (X - previousX) / dt, vy = (Y - previousY) / dt;
            float speed = (float)Math.Sqrt(vx * vx + vy * vy);
            if (speed > 300) { vx *= 300 / speed; vy *= 300 / speed; }
            float blend = Math.Min(1, dt * 8);
            PlayerVX += (vx - PlayerVX) * blend; PlayerVY += (vy - PlayerVY) * blend;
        }

        private Enemy FindEnemy(int id)
        {
            if (id <= 0) return null;
            Enemy found;
            if (tacticalIndex.TryGetValue(id, out found)) return found;
            for (int i = 0; i < Enemies.Count; i++) if (Enemies[i].Id == id) return Enemies[i];
            return null;
        }

        private void SpawnSquad()
        {
            if (Enemies.Count > EnemyLimit - 7) return;
            int relayCount = 0;
            for (int i = 0; i < Enemies.Count; i++) if (Enemies[i].Kind == "relay" && Enemies[i].Hp > 0) relayCount++;
            if (relayCount >= 3) return;
            Spawn("relay"); Enemy leader = Enemies[Enemies.Count - 1];
            string[] kinds = { "tank", "shooter", "shooter", "runner", "runner", "bomber" };
            for (int i = 0; i < kinds.Length; i++)
            {
                Spawn(kinds[i]); Enemy member = Enemies[Enemies.Count - 1];
                float angle = (float)(i * Math.PI * 2 / kinds.Length);
                member.X = Clamp(leader.X + (float)Math.Cos(angle) * 58, Left + member.R, Right - member.R);
                member.Y = Clamp(leader.Y + (float)Math.Sin(angle) * 58, Top + member.R, Bottom - member.R);
                member.RelayId = leader.Id;
                member.Cooldown += i * .28f;
                // Spawn graphics must reflect the actual squad position.
                AddEffect("spawn", member.X, member.Y, 0, 0, member.R + 8, .55f);
            }
            // A squad replaces part of the normal drip instead of adding unbounded density.
            spawnClock += 1.4f;
            tacticClock = 0;
        }

        private void UpdateTactics(float dt)
        {
            tacticalIndex.Clear();
            for (int i = 0; i < Enemies.Count; i++) tacticalIndex[Enemies[i].Id] = Enemies[i];
            for (int i = 0; i < Enemies.Count; i++)
            {
                Enemy e = Enemies[i];
                if (e.Kind == "relay" && e.Hp <= 0) DisruptRelay(e);
                e.Recovery = Math.Max(0, e.Recovery - dt);
                if (e.RelayId != 0)
                {
                    Enemy relay = FindEnemy(e.RelayId);
                    if (relay == null || relay.Hp <= 0 || relay.JamTime > 0 || relay.Stun > 0 || relay.Recovery > 0 || DistanceSquared(e.X, e.Y, relay.X, relay.Y) > 460 * 460) e.RelayId = 0;
                }
                e.Shielded = false;
            }
            tacticClock -= dt;
            if (tacticClock <= 0)
            {
                tacticClock = .22f;
                AssignSquads(); AssignGuards();
                for (int i = 0; i < Enemies.Count; i++) PlanPosition(Enemies[i]);
            }
            bool coordinated = false;
            for (int i = 0; i < Enemies.Count; i++)
            {
                Enemy e = Enemies[i]; if (e.Hp <= 0) continue;
                e.Shielded = IsProtected(e);
                if (e.RelayId > 0) coordinated = true;
            }
            Enemy focused = FindEnemy(FocusTargetId);
            if (focused == null || focused.Hp <= 0) FocusTargetId = 0;
            TacticName = coordinated ? "中继合围 · E 锁定信标 / 击破护卫侧翼" : "游猎 · 诱导预判，再转向或冲刺";
        }

        private void AssignSquads()
        {
            for (int i = 0; i < Enemies.Count; i++)
            {
                Enemy e = Enemies[i]; e.RelayId = 0;
                if (e.Kind == "relay" || e.Kind == "boss" || e.Hp <= 0 || e.Recovery > 0 || e.JamTime > 0) continue;
                float best = 420 * 420;
                for (int j = 0; j < Enemies.Count; j++)
                {
                    Enemy relay = Enemies[j];
                    if (relay.Kind != "relay" || relay.Hp <= 0 || relay.AttackPhase == -1 || relay.JamTime > 0 || relay.Stun > 0 || relay.Recovery > 0) continue;
                    float d = DistanceSquared(e.X, e.Y, relay.X, relay.Y);
                    if (d < best) { best = d; e.RelayId = relay.Id; }
                }
            }
        }

        private void AssignGuards()
        {
            for (int i = 0; i < Enemies.Count; i++) Enemies[i].GuardId = 0;
            for (int i = 0; i < Enemies.Count; i++)
            {
                Enemy guard = Enemies[i];
                if (guard.Kind != "tank" || guard.Hp <= 0 || guard.JamTime > 0 || guard.Stun > 0 || guard.Recovery > 0) continue;
                Enemy target = null; float best = 235 * 235;
                for (int j = 0; j < Enemies.Count; j++)
                {
                    Enemy e = Enemies[j];
                    if ((e.Kind != "shooter" && e.Kind != "relay") || e.Hp <= 0 || e.GuardId != 0 || e.Stun > 0) continue;
                    if (guard.RelayId > 0 && e.RelayId != guard.RelayId && e.Id != guard.RelayId) continue;
                    float distance = DistanceSquared(guard.X, guard.Y, e.X, e.Y);
                    if (e.Kind == "relay") distance *= 1.3f;
                    if (distance < best) { best = distance; target = e; }
                }
                if (target != null) { guard.GuardId = target.Id; target.GuardId = guard.Id; }
            }
        }

        private void PlanPosition(Enemy e)
        {
            float tx = DecoyTime > 0 ? DecoyX : X, ty = DecoyTime > 0 ? DecoyY : Y;
            float dx = e.X - tx, dy = e.Y - ty, distance = (float)Math.Sqrt(dx * dx + dy * dy);
            float nx = dx / Math.Max(1, distance), ny = dy / Math.Max(1, distance);
            float side = (e.Id & 1) == 0 ? 1 : -1;
            bool linked = e.RelayId > 0 && e.Recovery <= 0;
            e.OrderX = tx; e.OrderY = ty; e.Order = "追踪";
            if (e.Kind == "tank" && e.GuardId > 0)
            {
                Enemy ally = FindEnemy(e.GuardId);
                if (ally != null)
                {
                    float ax = tx - ally.X, ay = ty - ally.Y, ad = (float)Math.Sqrt(ax * ax + ay * ay);
                    e.OrderX = ally.X + ax / Math.Max(ad, 1) * 62;
                    e.OrderY = ally.Y + ay / Math.Max(ad, 1) * 62;
                    e.Order = "掩护";
                }
            }
            else if (e.Kind == "shooter" || e.Kind == "relay" || e.Kind == "bomber")
            {
                float orbit = e.Kind == "relay" ? 345 : e.Kind == "bomber" ? 325 : 300;
                Enemy leader = FindEnemy(e.RelayId);
                if (linked && leader != null)
                {
                    dx = leader.X - tx; dy = leader.Y - ty; distance = (float)Math.Sqrt(dx * dx + dy * dy);
                    nx = dx / Math.Max(distance, 1); ny = dy / Math.Max(distance, 1);
                }
                float lateral = linked && e.Kind == "shooter" ? side * 115 : side * 35;
                e.OrderX = tx + nx * orbit - ny * lateral; e.OrderY = ty + ny * orbit + nx * lateral;
                e.Order = e.Kind == "relay" ? "指挥" : e.Kind == "bomber" ? "封路" : linked ? "交叉火力" : "拉开距离";
            }
            else if ((e.Kind == "chaser" || e.Kind == "runner") && distance > 100)
            {
                float predict = linked ? .60f : .22f;
                float lateral = linked ? 115 : 42;
                e.OrderX = tx + (DecoyTime > 0 ? 0 : PlayerVX * predict) - ny * side * lateral;
                e.OrderY = ty + (DecoyTime > 0 ? 0 : PlayerVY * predict) + nx * side * lateral;
                e.Order = linked ? "侧翼截击" : "侧向追击";
            }
            e.OrderX = Clamp(e.OrderX, Left + e.R, Right - e.R);
            e.OrderY = Clamp(e.OrderY, Top + e.R, Bottom - e.R);
        }

        private bool IsProtected(Enemy e)
        {
            if (e.Hp <= 0 || e.GuardId <= 0 || (e.Kind != "shooter" && e.Kind != "relay")) return false;
            Enemy guard = FindEnemy(e.GuardId);
            if (guard == null || guard.Kind != "tank" || guard.Hp <= 0 || guard.Stun > 0 || guard.JamTime > 0 || guard.Recovery > 0 || guard.GuardId != e.Id) return false;
            float dx = X - e.X, dy = Y - e.Y, length = (float)Math.Sqrt(dx * dx + dy * dy);
            float gx = guard.X - e.X, gy = guard.Y - e.Y;
            float forward = (gx * dx + gy * dy) / Math.Max(1, length);
            float lateral = Math.Abs(gx * dy - gy * dx) / Math.Max(1, length);
            // Shield works only while the guard physically occupies the firing lane.
            return forward > 12 && forward < length && lateral < 44 && gx * gx + gy * gy < 125 * 125;
        }

        public void CancelEnemyWarning(int id)
        {
            for (int i = Hazards.Count - 1; i >= 0; i--) if (Hazards[i].OwnerId == id && Hazards[i].Warning > 0) RemoveFast(Hazards, i);
        }

        public void DisruptRelay(Enemy relay)
        {
            if (relay == null || relay.Kind != "relay" || relay.RelayBroken) return;
            if (relay.Hp <= 0) relay.RelayBroken = true;
            relay.Recovery = Math.Max(relay.Recovery, 3.2f);
            int count = 0;
            for (int i = 0; i < Enemies.Count; i++)
            {
                Enemy e = Enemies[i];
                if (e.Hp <= 0 || e.Kind == "boss" || (e.RelayId != relay.Id && e.GuardId != relay.Id)) continue;
                e.RelayId = e.GuardId = 0; e.Shielded = false;
                e.Stun = Math.Max(e.Stun, 1.4f); e.Recovery = Math.Max(e.Recovery, 3.2f);
                e.AttackPhase = 0; e.Windup = 0; e.Cooldown = Math.Max(e.Cooldown, 3.0f);
                e.VX = e.VY = 0; e.Order = "链路中断"; CancelEnemyWarning(e.Id); count++;
            }
            if (count > 0)
            {
                AddEffect("disrupt", relay.X, relay.Y, 0, 0, 150, .65f);
                Say("指挥链中断 · 编队失序，趁机突破", 2.8f); Event("break");
            }
            tacticClock = 0;
        }

        private void UpdateTacticalEnemies(float dt)
        {
            for (int i = 0; i < Enemies.Count; i++)
            {
                Enemy e = Enemies[i]; if (e.Hp <= 0) continue;
                e.Life += dt;
                if (e.AttackPhase == -1) { e.Timer -= dt; if (e.Timer <= 0) { e.AttackPhase = 0; PlanPosition(e); } continue; }
                if (e.Stun > 0) { e.Stun = Math.Max(0, e.Stun - dt); e.VX = e.VY = 0; continue; }
                e.Cooldown -= dt;
                if (e.AttackPhase == 1)
                {
                    e.VX = e.VY = 0; e.Windup -= dt;
                    if (e.Windup <= 0) FinishAttack(e);
                }
                else if (e.AttackPhase == 2)
                {
                    e.X += e.VX * dt; e.Y += e.VY * dt; e.Timer -= dt;
                    if (e.Timer <= 0) { e.AttackPhase = 0; e.Cooldown = 3.4f; e.Recovery = Math.Max(e.Recovery, .40f); }
                }
                else
                {
                    float distance = DistanceSquared(X, Y, e.X, e.Y);
                    bool special = e.Kind == "runner" || e.Kind == "shooter" || e.Kind == "bomber" || e.Kind == "boss";
                    float range = e.Kind == "runner" ? 390 : e.Kind == "boss" ? 1100 : 550;
                    if (special && e.Cooldown <= 0 && e.JamTime <= 0 && e.Recovery <= 0 && distance < range * range && TryBeginAttack(e)) { }
                    else
                    {
                        float dx = e.OrderX - e.X, dy = e.OrderY - e.Y, d = (float)Math.Sqrt(dx * dx + dy * dy);
                        float speed = e.Speed * (e.JamTime > 0 ? .5f : 1);
                        float travel = Math.Min(d, speed * dt);
                        if (e.Recovery > 0 && e.Kind == "runner") travel *= .35f;
                        e.VX = d > 6 ? dx / Math.Max(d, 1) * travel / dt : 0;
                        e.VY = d > 6 ? dy / Math.Max(d, 1) * travel / dt : 0;
                        e.X += e.VX * dt; e.Y += e.VY * dt;
                    }
                }
                e.X = Clamp(e.X, Left + e.R, Right - e.R); e.Y = Clamp(e.Y, Top + e.R, Bottom - e.R);
                if (DistanceSquared(X, Y, e.X, e.Y) < (e.R + 11) * (e.R + 11)) Hurt(e.Damage);
                if (Mode == "over") return;
            }
        }

        private bool TryBeginAttack(Enemy e)
        {
            if (Phase == "喘息" && e.Kind != "boss") return false;
            if (Time < nextSpecial) return false;
            int active = 0;
            bool bossWaiting = false;
            for (int i = 0; i < Enemies.Count; i++)
            {
                Enemy other = Enemies[i]; if (other.Hp <= 0) continue;
                if (other.AttackPhase == 1 || other.AttackPhase == 2) active++;
                if (other.Kind == "boss" && other.AttackPhase == 0 && other.Cooldown <= 0) bossWaiting = true;
            }
            if (active >= SpecialAttackLimit) return false;
            if (e.Kind != "boss" && bossWaiting && active >= SpecialAttackLimit - 1) return false;
            bool area = e.Kind == "bomber" || e.Kind == "boss";
            if (area && Hazards.Count >= 5) return false;
            float tx = DecoyTime > 0 ? DecoyX : X, ty = DecoyTime > 0 ? DecoyY : Y;
            float lead = e.Kind == "runner" ? 1.10f : e.Kind == "shooter" ? 1.70f : e.Kind == "boss" ? 1.10f : 1.20f;
            if (e.Kind == "shooter" && DecoyTime <= 0)
            {
                // Solve an intercept using the observed velocity and a fixed 0.9s firing tell.
                float px = X + PlayerVX * .9f - e.X, py = Y + PlayerVY * .9f - e.Y;
                float a = PlayerVX * PlayerVX + PlayerVY * PlayerVY - 255 * 255;
                float b = 2 * (px * PlayerVX + py * PlayerVY), c = px * px + py * py;
                float discriminant = b * b - 4 * a * c;
                if (discriminant >= 0 && Math.Abs(a) > .01f)
                {
                    float t1 = (-b - (float)Math.Sqrt(discriminant)) / (2 * a), t2 = (-b + (float)Math.Sqrt(discriminant)) / (2 * a);
                    float travel = t1 > 0 ? t1 : t2 > 0 ? t2 : .8f;
                    lead = Math.Min(2.6f, .9f + travel);
                }
            }
            if (e.RelayId > 0 && e.Kind != "shooter") lead += .05f;
            if (DecoyTime <= 0) { tx += PlayerVX * lead; ty += PlayerVY * lead; }
            float radius = e.Kind == "boss" ? 96 : 64;
            tx = Clamp(tx, Left + 18, Right - 18); ty = Clamp(ty, Top + 18, Bottom - 18);
            if (!LeavesEscape(e, tx, ty, area ? radius : 22)) { e.Cooldown = .28f; return false; }
            e.AttackPhase = 1; e.TargetX = tx; e.TargetY = ty;
            e.Windup = e.Kind == "runner" ? .85f : e.Kind == "shooter" ? .9f : e.Kind == "boss" ? 1.15f : 1.25f;
            e.VX = e.VY = 0;
            // Stagger the starts: no frame can suddenly open every attack lane.
            nextSpecial = Time + .30f;
            if (area)
            {
                Hazard h = new Hazard(); h.OwnerId = e.Id; h.X = tx; h.Y = ty; h.R = radius;
                h.Warning = e.Windup; h.Life = e.Kind == "boss" ? 1.1f : 2.2f; h.Damage = e.Damage * .65f;
                if (Hazards.Count < HazardLimit) Hazards.Add(h);
            }
            Event("warning"); return true;
        }

        private bool LeavesEscape(Enemy attacker, float tx, float ty, float radius)
        {
            // Reserve at least one walkable direction. A warning is not yet a blocking floor:
            // allow crossing it before detonation, but always require a safe destination.
            // This is a bounded eight-sector fairness check, not navigation over the whole arena.
            bool proposedArea = attacker.Kind == "bomber" || attacker.Kind == "boss";
            float proposedWarning = attacker.Kind == "boss" ? 1.15f : 1.25f;
            for (int sector = 0; sector < 8; sector++)
            {
                float angle = sector * (float)Math.PI / 4;
                float ex = X + (float)Math.Cos(angle) * 175, ey = Y + (float)Math.Sin(angle) * 175;
                if (ex < Left + 18 || ex > Right - 18 || ey < Top + 18 || ey > Bottom - 18) continue;
                bool safe = true;
                for (int sample = 1; sample <= 2 && safe; sample++)
                {
                    float px = X + (ex - X) * sample / 2, py = Y + (ey - Y) * sample / 2;
                    float arrive = 175f * sample / 2 / (220 + Rank("speed") * 16);
                    if ((!proposedArea || sample == 2 || proposedWarning <= arrive) && AttackCovers(attacker, tx, ty, radius, px, py)) { safe = false; break; }
                    for (int j = 0; j < Hazards.Count && safe; j++)
                        if ((sample == 2 || Hazards[j].Warning <= arrive) && DistanceSquared(px, py, Hazards[j].X, Hazards[j].Y) < (Hazards[j].R + 18) * (Hazards[j].R + 18)) safe = false;
                    for (int j = 0; j < Enemies.Count && safe; j++)
                    {
                        Enemy e = Enemies[j];
                        if (e.Hp <= 0 || e.AttackPhase != 1 || e.Kind == "boss" || e.Kind == "bomber") continue;
                        if (AttackCovers(e, e.TargetX, e.TargetY, 24, px, py)) safe = false;
                    }
                }
                if (safe) return true;
            }
            return false;
        }

        private bool AttackCovers(Enemy e, float tx, float ty, float radius, float px, float py)
        {
            if (e.Kind == "bomber" || e.Kind == "boss") return DistanceSquared(px, py, tx, ty) < (radius + 18) * (radius + 18);
            float dx = tx - e.X, dy = ty - e.Y, d2 = dx * dx + dy * dy;
            float t = Clamp(((px - e.X) * dx + (py - e.Y) * dy) / Math.Max(1, d2), 0, 1.4f);
            return DistanceSquared(px, py, e.X + dx * t, e.Y + dy * t) < (radius + 15) * (radius + 15);
        }

        private void FinishAttack(Enemy e)
        {
            if (e.Kind == "runner")
            {
                float dx = e.TargetX - e.X, dy = e.TargetY - e.Y, d = (float)Math.Sqrt(dx * dx + dy * dy);
                e.VX = dx / Math.Max(1, d) * 490; e.VY = dy / Math.Max(1, d) * 490;
                e.AttackPhase = 2; e.Timer = .58f;
            }
            else if (e.Kind == "shooter")
            {
                float angle = (float)Math.Atan2(e.TargetY - e.Y, e.TargetX - e.X);
                int count = Time > 180 ? 3 : 1;
                for (int j = 0; j < count; j++) AddShot(e.X, e.Y, angle + (j - (count - 1) / 2f) * .18f, 255, e.Damage, true, 0, "enemy");
                e.AttackPhase = 0; e.Cooldown = e.RelayId > 0 ? 2.65f : 3.15f;
            }
            else
            {
                float radius = e.Kind == "boss" ? 96 : 64;
                AddEffect("aoeBlast", e.TargetX, e.TargetY, 0, 0, radius, .42f);
                if (DistanceSquared(X, Y, e.TargetX, e.TargetY) < (radius + 10) * (radius + 10)) Hurt(e.Damage * 1.25f);
                for (int i = 0; i < Hazards.Count; i++) if (Hazards[i].OwnerId == e.Id && Hazards[i].Warning > 0) Hazards[i].Warning = 0;
                if (e.Kind == "boss")
                {
                    int count = 12 + Math.Min(8, bossCycle * 2);
                    // Leave a readable three-bullet opening in every boss ring.
                    int opening = ((int)e.Life / 3) % count;
                    for (int j = 0; j < count; j++)
                    {
                        int gap = (j - opening + count) % count;
                        if (gap < 3) continue;
                        AddShot(e.X, e.Y, j * (float)Math.PI * 2 / count + e.Life * .1f, 170, e.Damage * .8f, true, 0, "boss");
                    }
                }
                e.AttackPhase = 0; e.Cooldown = e.Kind == "boss" ? 3.0f : 4.1f;
            }
        }

        private void UpdateHazards(float dt)
        {
            for (int i = Hazards.Count - 1; i >= 0; i--)
            {
                Hazard h = Hazards[i];
                if (h.Warning > 0)
                {
                    Enemy owner = FindEnemy(h.OwnerId);
                    if (owner == null || owner.Hp <= 0 || owner.AttackPhase != 1) { RemoveFast(Hazards, i); continue; }
                    h.Warning = Math.Max(.001f, owner.Windup); continue;
                }
                h.Life -= dt;
                if (h.Life <= 0) { RemoveFast(Hazards, i); continue; }
                if (DistanceSquared(X, Y, h.X, h.Y) < (h.R + 8) * (h.R + 8)) Hurt(h.Damage);
                if (Mode == "over") return;
            }
        }
    }
}
