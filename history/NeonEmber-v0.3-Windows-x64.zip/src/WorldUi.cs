using System;
using System.Collections.Generic;
namespace NeonEmber {
public static partial class Program {
    static bool journal;
    static int journalPage, savedChapter;
    static float archiveUntil;
    static readonly string[] SchoolIds = {"ember","echo","forge"};
    static readonly Dictionary<int,Enemy> enemyLookup = new Dictionary<int,Enemy>();
    static Col SchoolColor(string id) { return id=="ember"?Gold:id=="echo"?Violet:Cyan; }
    static int UnlockedChapter() { return Math.Min(Lore.StoryCount-1,Math.Max(savedChapter,game==null?0:game.StoryChapter)); }
    static bool PrepareWorldScenario() {
        if(scenario=="transition"){
            game.Time=89.99f;game.Coins=200;game.Orbs.Add(new Orb{X=game.X,Y=game.Y,Value=game.NextXp});game.Step(1f/60,0,0,false);
            if(game.Mode!="level")throw new InvalidOperationException("Transition fixture did not reach level selection.");return true;
        }
        if(scenario=="upgrades"){
            game.Ranks["ember_brand"]=3;game.Ranks["echo_jammer"]=3;game.Ranks["forge_breaker"]=3;game.Level=12;game.Mode="level";game.Choices.Clear();
            game.Choices.Add(game.WorldUpgradeInfo("ember_brand"));game.Choices.Add(game.WorldUpgradeInfo("echo_jammer"));game.Choices.Add(game.WorldUpgradeInfo("forge_breaker"));game.Ranks["ember_brand"]=2;game.Ranks["echo_jammer"]=2;game.Ranks["forge_breaker"]=2;return true;
        }
        if(scenario=="archive"){game.StoryChapter=2;journal=true;journalPage=2;return true;}
        if(scenario=="schools"){
            game.Ranks["ember_brand"]=2;game.Ranks["ember_breach"]=2;game.Ranks["ember_cascade"]=2;game.Ranks["echo_jammer"]=2;game.Ranks["forge_ward"]=2;game.Ward=game.MaxWard;buildView=true;return true;
        }
        if(scenario!="tactics")return false;
        game.Time=35;game.Ranks["bolt"]=2;game.Ranks["echo_jammer"]=1;game.Ranks["forge_ward"]=1;game.Ward=14;
        string[] kinds={"relay","tank","shooter","shooter","runner","runner","bomber"};float[] xs={990,905,955,970,430,480,520};float[] ys={330,340,242,460,200,536,407};
        for(int i=0;i<kinds.Length;i++){game.Enemies.Add(new Enemy{Id=301+i,Kind=kinds[i],X=xs[i],Y=ys[i],R=i==0?20:i==1?22:13,Hp=800,MaxHp=800,Speed=i==1?72:88,Damage=12,Cooldown=i==6?0:.55f});}
        for(int i=0;i<40;i++)game.Step(1f/60,1,0,false);
        game.FocusTargetId=301;game.AnnouncementTime=0;game.Hp=100;game.Coins=62;game.Kills=77;
        return true;
    }
    static void Fit(string s,float x,float y,float max,float size,Col color) { if(s==null)return;float w=TW(s,size);T(s,x,y,w>max?size*max/w:size,color); }
    static bool ModalButton(string s,float x,float y,float w,float h,bool enabled) {
        bool hover=enabled&&Hit(x,y,w,h);Card(x,y,w,h,hover?Cyan:Line);TC(s,x+w/2,y+(h-17)/2,17,enabled?White:Muted.Alpha(.4f));return ConsumeClick(hover);
    }
    static void TargetInput() {
        if(R.IsKeyPressed(69)){
            Enemy best=null;float score=float.MaxValue;
            foreach(Enemy e in game.Enemies)if(e.Kind=="relay"&&e.Hp>0){float d=(e.X-game.X)*(e.X-game.X)+(e.Y-game.Y)*(e.Y-game.Y);if(d<score){score=d;best=e;}}
            if(best==null){foreach(Enemy e in game.Enemies)if(e.Hp>0){float d=(e.X-game.X)*(e.X-game.X)+(e.Y-game.Y)*(e.Y-game.Y);if(d<score){score=d;best=e;}}}
            game.FocusTargetId=best==null?0:game.FocusTargetId==best.Id?0:best.Id;
        }
        if(click&&my>104&&my<640){Enemy chosen=null;float distance=900;foreach(Enemy e in game.Enemies){float d=(e.X-mx)*(e.X-mx)+(e.Y-my)*(e.Y-my);if(e.Hp>0&&d<(e.R+14)*(e.R+14)&&d<distance){distance=d;chosen=e;}}game.FocusTargetId=chosen==null?0:chosen.Id;}
    }
    static void DrawTacticalGround() {
        enemyLookup.Clear();foreach(Enemy e in game.Enemies)enemyLookup[e.Id]=e;
        foreach(Hazard h in game.Hazards){bool warning=h.Warning>0;Col c=warning?Gold:Pink;R.DrawCircleV(new V(h.X,h.Y),h.R,c.Alpha(warning?.055f:.15f));R.DrawCircleLinesV(new V(h.X,h.Y),h.R,c.Alpha(.9f));if(warning){R.DrawRing(new V(h.X,h.Y),h.R-3,h.R,0,Math.Min(360,h.Warning*300),24,c.Alpha(.55f));TC("封锁预告",h.X,h.Y-8,12,Gold);}else{L(h.X-8,h.Y-8,h.X+8,h.Y+8,2,Pink);L(h.X-8,h.Y+8,h.X+8,h.Y-8,2,Pink);}}
        foreach(Enemy e in game.Enemies){Enemy other;if(e.RelayId!=0&&enemyLookup.TryGetValue(e.RelayId,out other)&&other.Hp>0){L(e.X,e.Y,other.X,other.Y,1,Violet.Alpha(.24f));}if(e.Shielded&&e.GuardId!=0&&enemyLookup.TryGetValue(e.GuardId,out other)&&other.Hp>0){L(e.X,e.Y,other.X,other.Y,2,Cyan.Alpha(.38f));}}
    }
    static void DrawTacticalDetails() {
        foreach(Enemy e in game.Enemies){
            if(e.Kind=="relay"){R.DrawPolyLinesEx(new V(e.X,e.Y),6,e.R+8,-realTime*25,1.5f,Violet);TC("指挥节点",e.X,e.Y-e.R-28,12,Violet);}
            if(e.BurnTime>0){R.DrawRing(new V(e.X,e.Y),e.R+2,e.R+4,realTime*120,realTime*120+170,16,Gold.Alpha(.85f));}
            if(e.Shielded)R.DrawRing(new V(e.X,e.Y),e.R+5,e.R+7,0,360,24,Cyan.Alpha(.7f));
            if(e.Stun>0){R.DrawPolyLinesEx(new V(e.X,e.Y),4,e.R+11,45,1,Violet);TC("失联",e.X,e.Y+e.R+9,11,Violet);}
            if(e.Id==game.FocusTargetId){float r=e.R+12;L(e.X-r,e.Y-r,e.X-r+8,e.Y-r,2,White);L(e.X-r,e.Y-r,e.X-r,e.Y-r+8,2,White);L(e.X+r,e.Y+r,e.X+r-8,e.Y+r,2,White);L(e.X+r,e.Y+r,e.X+r,e.Y+r-8,2,White);TC("优先目标",e.X,e.Y+e.R+25,12,White);}
        }
        if(game.DecoyTime>0){R.DrawPolyLinesEx(new V(game.DecoyX,game.DecoyY),3,17,0,2,Violet.Alpha(.65f));R.DrawCircleLinesV(new V(game.DecoyX,game.DecoyY),29,Violet.Alpha(.4f));T("回声",game.DecoyX+24,game.DecoyY-8,12,Violet);}
        if(game.MaxWard>0&&game.Ward>0)R.DrawRing(new V(game.X,game.Y),27,29,-90,-90+360*game.Ward/game.MaxWard,32,Cyan.Alpha(.8f));
    }
    static void DrawTacticalHud() {
        if(game.Mode!="play")return;
        string tactic=string.IsNullOrEmpty(game.TacticName)?"校正网络正在扫描":game.TacticName;
        Fit(tactic,42,607,600,15,Gold);T("E 节点优先 · 点击敌人锁定 · 点击空地解除",792,610,12,Muted);
        if(game.MaxWard>0)T("护盾 "+Math.Ceiling(game.Ward)+" / "+game.MaxWard,163,68,12,Cyan);
        if(realTime<archiveUntil){Card(888,116,355,70,Violet);T("记忆已解封  /  J 阅读",903,130,15,Violet);Fit(Lore.StoryTitle(UnlockedChapter()),903,157,320,15,White);}
    }
    static void DrawMenu() {
        Box(0,0,1280,720,BG.Alpha(.96f));T("N / E",62,36,19,Cyan);T("NEON EMBER / ARCHIVE BREACH",136,39,14,Muted);T("WINDOWS / v0.3",1010,39,14,Muted);
        T("未删之城",66,99,19,Gold);T("霓虹余烬",60,133,61,White);T("当记忆成为罪证，你负责让它抵达明天。",65,219,21,White);
        T("你是携带原始记忆的信使。校正网络开始联手追捕，而三个地下组织递来了各自的技术。",66,260,16,Muted);
        Emblem(1081,173,71,realTime*8,Violet);R.DrawCircleLinesV(new V(1081,173),97,Line);
        T("01 / 选择起始武器与技术",65,306,15,Muted);
        for(int i=0;i<3;i++){
            float x=65+i*387;Col color=SchoolColor(SchoolIds[i]);bool selected=weapon==i,hover=Hit(x,340,365,218)&&!journal&&!help;
            Card(x,340,365,218,selected?color:hover?Muted:Line);if(selected)Box(x+1,360,3,42,color);
            T(Lore.SchoolName(SchoolIds[i]),x+23,358,15,color);T(WeaponNames[i],x+23,388,29,White);T(WeaponSub[i],x+23,432,15,color);Wrap(WeaponDesc[i],x+23,473,319,16,Muted);
            if(hover&&click)weapon=i;
        }
        if(Button(difficulty==0?"标准协议  ›":"高压协议  ›",65,586,203,48,false,true))difficulty=1-difficulty;
        if(Button("J  记忆档案",286,586,202,48,false,true)){journal=true;journalPage=UnlockedChapter();}
        T("最高生存 "+Clock(difficulty==0?bestTime:hardBest),519,602,16,White);
        if(Button("携带记忆，出发  ↗",884,582,316,57,true,true))Start();
        T("WASD 移动 / 空格冲刺 / 自动攻击 / E 优先拆除节点",65,667,14,Muted);T("Enter 开始 · H 指南 · F11 全屏",864,667,14,Muted);
        if(persistWarning!="")T(persistWarning,65,286,12,Gold);
    }
    static string UpgradeSchool(Upgrade u){return string.IsNullOrEmpty(u.School)?"":u.School;}
    static void DrawLevel() {
        Shade();T("RECONSTRUCTION / "+game.Level.ToString("00"),116,107,15,Cyan);T("选择技术，改写追捕规则",112,138,35,White);
        T("每系累计 6 点启动核心协议；跨系可产生联动。所有卡片可混搭。",115,193,16,Muted);
        for(int i=0;i<game.Choices.Count;i++){
            Upgrade u=game.Choices[i];float x=114+i*358;bool hover=Hit(x,251,336,302)&&!help&&!journal&&!buildView;string school=UpgradeSchool(u);Col c=u.Name.Contains("进化")?Gold:school!=""?SchoolColor(school):Cyan;
            Card(x,251,336,302,hover?c:Line);T("0"+(i+1)+" / "+u.Tag,x+22,272,14,c);Fit(u.Name,x+22,311,290,25,White);
            Wrap(u.Description,x+22,358,288,16,White.Alpha(.86f));
            if(!string.IsNullOrEmpty(u.Flavor))Wrap(u.Flavor,x+22,461,288,13,Muted);
            T("按 "+(i+1)+" 选择  ↗",x+22,520,14,c);if(ConsumeClick(hover)){game.Choose(i);break;}
        }
        Fit(game.SchoolProgressText(),115,581,715,16,Muted);if(Button("R 刷新 / 剩余 "+game.Rerolls,879,577,286,46,false,game.Rerolls>0))game.Reroll();
    }
    static void DrawShop() {
        Shade();T("DEAD DROP / 地下接驳站",115,106,15,Cyan);T("他们也在等待这份记忆",111,143,36,White);T("修补匠「弥」：补好装甲，带上能破局的技术。网络不会永远失明。",115,200,17,Muted);
        T("合金  "+game.Coins,1000,152,22,Gold);
        for(int i=0;i<game.ShopOffers.Count;i++){
            Upgrade u=game.ShopOffers[i];float x=114+i*358;string school=UpgradeSchool(u);Col c=school==""?Cyan:SchoolColor(school);Card(x,259,336,285,Line);T(u.Tag,x+22,281,14,c);Fit(u.Name,x+22,320,290,25,White);Wrap(u.Description,x+22,363,290,16,Muted);
            if(!string.IsNullOrEmpty(u.Flavor))Wrap(u.Flavor,x+22,435,290,12,c.Alpha(.6f));
            if(Button(u.Price==0?"免费领取":"购买 / "+u.Price+" 合金",x+22,485,292,40,false,game.Coins>=u.Price)){game.Buy(i);break;}
        }
        Fit(game.SchoolProgressText(),115,586,730,15,Muted);if(Button("继续传递  ↗",880,574,286,51,true,true))game.LeaveShop();
    }
    static void DrawBuild() {
        Shade();Card(122,37,1036,648,Line);T("BUILD / 技术谱系 · 战场暂停",154,63,15,Cyan);T("你选择了怎样的反抗？",151,95,32,White);
        string[] weaponKeys={"bolt","arc","blade"};
        string[] summaries={"点燃目标 · 惩罚破绽 · 传播火种","留下残像 · 干扰指挥 · 多武器共鸣","充能护盾 · 冲刺破阵 · 拦截弹幕"};
        string detail="悬停技术条目或觉醒名称可阅读效果。武器等级不计入体系点数。";
        for(int i=0;i<3;i++){
            float x=154+i*326;string school=SchoolIds[i];Col c=SchoolColor(school);Card(x,150,310,282,Line);T(Lore.SchoolName(school),x+18,165,21,c);Fit(summaries[i],x+18,199,275,14,Muted);
            int rank=Rank(weaponKeys[i]);T(WeaponNames[i]+" / "+(rank==0?"未装备":rank>=5?"已进化":"Lv."+rank),x+18,232,17,White);
            int row=0;foreach(string id in Lore.UpgradeIds){Upgrade u=game.WorldUpgradeInfo(id);if(u.School!=school)continue;bool hover=Hit(x+14,261+row*31,280,29);string name=u.Name.Substring(0,u.Name.LastIndexOf(' '));Fit(name,x+18,267+row*31,219,16,hover?White:Muted);T(Rank(id)+" / 3",x+244,267+row*31,14,Rank(id)>0?White:Muted.Alpha(.45f));if(hover)detail=(Rank(id)>0?"当前效果 / ":"1 级预览 / ")+u.Description;row++;}
            T("投入 "+game.SchoolPoints(school)+" / 6",x+18,373,15,c);Fit((game.HasSchoolCapstone(school)?"已觉醒 / ":"6 点觉醒 / ")+Lore.CapstoneName(school),x+18,400,276,14,c);
            if(Hit(x+14,368,280,53))detail=Lore.CapstoneDescription(school);
        }
        Wrap(game.SynergyText(),156,445,965,14,Gold);
        string[] ids={"power","haste","vitality","speed","magnet","scholar","crit","guard","dash"};string[] names={"增伤","攻速","装甲","移速","拾取","经验","暴击","减伤","冲刺"};
        for(int i=0;i<9;i++)T(names[i]+" "+Rank(ids[i]),155+i*107,518,14,Muted);
        T("伤害 ×"+game.PowerMultiplier.ToString("F2")+"   /   频率 ×"+game.FireRateMultiplier.ToString("F2")+"   /   护盾 "+Math.Ceiling(game.Ward)+" / "+game.MaxWard,155,547,17,Cyan);
        Wrap(detail,155,578,965,15,Muted);T("B / ESC 返回",155,642,14,Muted);
        if(ModalButton("返回战场",862,623,260,42,!help&&!journal))buildView=false;
    }
    static void DrawJournal() {
        Shade();Card(91,42,1098,634,Line);T("ARCHIVE / 已解封记忆",126,68,15,Violet);T("一座城，四份互相矛盾的证词",122,103,33,White);
        int unlocked=UnlockedChapter();for(int i=0;i<Lore.StoryCount;i++){
            float y=174+i*81;bool open=i<=unlocked,selected=i==journalPage;Card(124,y,280,66,selected?Violet:Line);T("0"+i+" / "+(open?"可读取":"尚未解密"),139,y+10,12,open?Violet:Muted.Alpha(.5f));Fit(open?Lore.StoryTitle(i):"击破第 "+i+" 位监察者",139,y+34,250,16,open?White:Muted.Alpha(.5f));if(open&&click&&Hit(124,y,280,66))journalPage=i;
        }
        T("记录会跨局保留。",125,526,14,Muted);Wrap("每局前 3 次击破监察者，依次获得证词。读完后继续无尽模式，将未删记忆传给更远的街区。",125,555,270,14,Muted);
        L(429,174,429,618,1,Line);T(Lore.StoryTitle(journalPage),465,179,26,White);Wrap(Lore.StoryBody(journalPage),465,233,675,18,Muted);
        if(ModalButton("关闭档案 / J",895,609,255,43,true))journal=false;
    }
    static void DrawHelp() {
        Shade();Card(142,42,996,636,Line);T("FIELD MANUAL / 反校正战术",177,67,15,Cyan);T("观察协作，再拆掉它",173,101,33,White);
        string[] labels={"WASD / 方向键","SPACE","E / 鼠标点击","1 / 2 / 3 · R","B / J / ESC"};string[] desc={"移动；武器自动攻击，无需持续点击。","冲刺突围；回声系可留下诱饵，铸卫系可冲击封锁。","E 优先锁定指挥节点；点怪指定目标，点空地解除。","选择升级 / 重掷；初始 3 次，击破监察者可补充。","查看构筑 / 读取剧情档案 / 暂停与返回。"};
        for(int i=0;i<labels.Length;i++){T(labels[i],179,168+i*38,17,i==2?Gold:White);T(desc[i],416,168+i*38,16,Muted);}
        L(178,371,1102,371,1,Line);Wrap("紫色连线：节点正在协调随从。击破或干扰节点，打断整组进攻。\n青色护盾：盾卫处于掩护位置。绕侧、拉开距离或冲刺干扰盾卫。\n橙色封路预告：落点已经锁定。红区生效前改向，避免只绕圈直走。\n三系各 3 项技术，每项 3 级；同系 6 点觉醒，两系各 2 点产生联动。",179,393,918,17,Muted);
        T("预警锁定后改变方向，先拆节点或守卫，再穿过恢复期形成的缺口。",179,532,17,Gold);T("有限预判 / 可读意图 / 协作有依赖 / 破局有收益",179,569,14,Cyan);
        if(ModalButton("明白了 / H",845,610,257,43,!journal))help=false;
    }
    static void DrawAttackWarning(Enemy e,Col c) {
        if(e.AttackPhase!=1||e.Kind=="bomber"||e.Kind=="boss")return;
        float tx=e.TargetX,ty=e.TargetY;
        if(e.Kind=="runner"){float dx=tx-e.X,dy=ty-e.Y,len=Math.Max(1,(float)Math.Sqrt(dx*dx+dy*dy));tx=e.X+dx/len*284.2f;ty=e.Y+dy/len*284.2f;}
        L(e.X,e.Y,tx,ty,2,c.Alpha(.65f));R.DrawCircleLinesV(new V(tx,ty),8,c.Alpha(.75f));
    }
}
}
